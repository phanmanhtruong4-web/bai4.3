namespace CalculatorApp
{
    partial class CalcForm
    {
        private System.ComponentModel.IContainer components = null;

        private TextBox txtDisplay;

        private Button btn0, btn1, btn2, btn3, btn4;
        private Button btn5, btn6, btn7, btn8, btn9;

        private Button btnAdd;
        private Button btnSub;
        private Button btnMul;
        private Button btnDiv;
        private Button btnEquals;
        private Button btnClear;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();

            this.txtDisplay = new TextBox();

            this.btn0 = new Button();
            this.btn1 = new Button();
            this.btn2 = new Button();
            this.btn3 = new Button();
            this.btn4 = new Button();
            this.btn5 = new Button();
            this.btn6 = new Button();
            this.btn7 = new Button();
            this.btn8 = new Button();
            this.btn9 = new Button();

            this.btnAdd = new Button();
            this.btnSub = new Button();
            this.btnMul = new Button();
            this.btnDiv = new Button();
            this.btnEquals = new Button();
            this.btnClear = new Button();

            this.SuspendLayout();

            // txtDisplay
            this.txtDisplay.Location = new Point(20, 20);
            this.txtDisplay.Name = "txtDisplay";
            this.txtDisplay.Size = new Size(270, 40);
            this.txtDisplay.Font = new Font("Segoe UI", 16F);
            this.txtDisplay.TextAlign = HorizontalAlignment.Right;
            this.txtDisplay.ReadOnly = true;
            this.txtDisplay.TabStop = false;

            // Số 0..9 -- cùng dùng chung NumberButton_Click
            ConfigButton(this.btn7, "7", 20, 70);
            ConfigButton(this.btn8, "8", 90, 70);
            ConfigButton(this.btn9, "9", 160, 70);
            ConfigButton(this.btn4, "4", 20, 130);
            ConfigButton(this.btn5, "5", 90, 130);
            ConfigButton(this.btn6, "6", 160, 130);
            ConfigButton(this.btn1, "1", 20, 190);
            ConfigButton(this.btn2, "2", 90, 190);
            ConfigButton(this.btn3, "3", 160, 190);
            ConfigButton(this.btn0, "0", 90, 250);

            this.btn0.Click += new EventHandler(this.NumberButton_Click);
            this.btn1.Click += new EventHandler(this.NumberButton_Click);
            this.btn2.Click += new EventHandler(this.NumberButton_Click);
            this.btn3.Click += new EventHandler(this.NumberButton_Click);
            this.btn4.Click += new EventHandler(this.NumberButton_Click);
            this.btn5.Click += new EventHandler(this.NumberButton_Click);
            this.btn6.Click += new EventHandler(this.NumberButton_Click);
            this.btn7.Click += new EventHandler(this.NumberButton_Click);
            this.btn8.Click += new EventHandler(this.NumberButton_Click);
            this.btn9.Click += new EventHandler(this.NumberButton_Click);

            // Nút phép toán
            ConfigButton(this.btnDiv, "/", 230, 70);
            ConfigButton(this.btnMul, "*", 230, 130);
            ConfigButton(this.btnSub, "-", 230, 190);
            ConfigButton(this.btnAdd, "+", 230, 250);
            ConfigButton(this.btnClear, "C", 20, 250);
            ConfigButton(this.btnEquals, "=", 160, 250);

            this.btnAdd.Click += new EventHandler(this.OperatorButton_Click);
            this.btnSub.Click += new EventHandler(this.OperatorButton_Click);
            this.btnMul.Click += new EventHandler(this.OperatorButton_Click);
            this.btnDiv.Click += new EventHandler(this.OperatorButton_Click);
            this.btnEquals.Click += new EventHandler(this.btnEquals_Click);
            this.btnClear.Click += new EventHandler(this.btnClear_Click);

            // CalcForm
            this.ClientSize = new Size(330, 320);
            this.Controls.Add(this.txtDisplay);
            this.Controls.Add(this.btn0);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btn4);
            this.Controls.Add(this.btn5);
            this.Controls.Add(this.btn6);
            this.Controls.Add(this.btn7);
            this.Controls.Add(this.btn8);
            this.Controls.Add(this.btn9);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnSub);
            this.Controls.Add(this.btnMul);
            this.Controls.Add(this.btnDiv);
            this.Controls.Add(this.btnEquals);
            this.Controls.Add(this.btnClear);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "CalcForm";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Máy tính";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        /// <summary>
        /// Khởi tạo nhanh thuộc tính chung (Text/Location/Size/Font) cho mỗi nút bấm.
        /// </summary>
        private void ConfigButton(Button btn, string text, int x, int y)
        {
            btn.Text = text;
            btn.Location = new Point(x, y);
            btn.Size = new Size(60, 50);
            btn.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btn.UseVisualStyleBackColor = true;
        }

        #endregion
    }
}
