# CalculatorApp (WinForms - C#)

Form máy tính minh họa: dùng **chung 1 Event Handler** cho 10 nút số (`btn0`..`btn9`) thông qua tham số `object sender`.

## Cấu trúc
- `CalcForm.Designer.cs`:
  - Khai báo `txtDisplay`, `btn0..btn9` và các nút phép toán `+ - * / = C`.
  - Cả 10 nút số đều gán chung sự kiện `NumberButton_Click`.
  - Các nút `+ - *  /` gán chung `OperatorButton_Click`.
- `CalcForm.cs`:
  - `NumberButton_Click(object? sender, EventArgs e)`:
    ```csharp
    Button btn = (Button)sender!;   // ép kiểu object -> Button
    txtDisplay.Text += btn.Text;    // nối chuỗi vào ô hiển thị
    ```
  - `OperatorButton_Click` lưu toán hạng & phép toán đang chờ.
  - `btnEquals_Click` tính kết quả; `btnClear_Click` reset (`C`).
  - Có kiểm tra chia cho 0.
- `Program.cs` — entry point.

## Chạy thử (Windows, cần .NET 8 SDK)
```
dotnet run
```

## Đưa lên GitHub
```
cd CalculatorApp
git init
git add .
git commit -m "Calculator form: shared NumberButton_Click via object sender"
git branch -M main
git remote add origin <URL_repo_cua_ban>
git push -u origin main
```
