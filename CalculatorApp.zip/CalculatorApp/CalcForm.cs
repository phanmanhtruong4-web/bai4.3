namespace CalculatorApp
{
    public partial class CalcForm : Form
    {
        // Lưu toán hạng thứ nhất và phép toán đang chờ (+, -, *, /)
        private double firstOperand = 0;
        private string pendingOperator = string.Empty;

        // true = lần bấm số tiếp theo sẽ bắt đầu một số mới (không nối vào số cũ)
        private bool startNewNumber = true;

        public CalcForm()
        {
            InitializeComponent();
            txtDisplay.Text = "0";
        }

        /// <summary>
        /// Event Handler DÙNG CHUNG cho 10 nút bấm số (btn0..btn9).
        /// Ép kiểu (Button)sender để lấy Text của nút vừa được bấm,
        /// rồi nối chuỗi vào txtDisplay.Text.
        /// </summary>
        private void NumberButton_Click(object? sender, EventArgs e)
        {
            Button btn = (Button)sender!;   // Ép kiểu object -> Button
            string digit = btn.Text;

            if (startNewNumber || txtDisplay.Text == "0")
            {
                txtDisplay.Text = digit;
                startNewNumber = false;
            }
            else
            {
                txtDisplay.Text += digit;
            }
        }

        /// <summary>
        /// Xử lý chung cho các nút phép toán (+, -, *, /).
        /// Lưu lại toán hạng đầu và phép toán, chờ toán hạng thứ hai.
        /// </summary>
        private void OperatorButton_Click(object? sender, EventArgs e)
        {
            Button btn = (Button)sender!;

            // Nếu người dùng bấm nhiều phép toán liên tiếp, tính luôn kết quả tạm trước đó
            if (!string.IsNullOrEmpty(pendingOperator) && !startNewNumber)
            {
                Calculate();
            }
            else
            {
                firstOperand = double.Parse(txtDisplay.Text);
            }

            pendingOperator = btn.Text;
            startNewNumber = true;
        }

        private void btnEquals_Click(object? sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(pendingOperator))
                return;

            Calculate();
            pendingOperator = string.Empty;
            startNewNumber = true;
        }

        private void btnClear_Click(object? sender, EventArgs e)
        {
            txtDisplay.Text = "0";
            firstOperand = 0;
            pendingOperator = string.Empty;
            startNewNumber = true;
        }

        /// <summary>
        /// Thực hiện phép toán đang chờ giữa firstOperand và số hiện trên txtDisplay.
        /// </summary>
        private void Calculate()
        {
            double secondOperand = double.Parse(txtDisplay.Text);
            double result;

            switch (pendingOperator)
            {
                case "+":
                    result = firstOperand + secondOperand;
                    break;
                case "-":
                    result = firstOperand - secondOperand;
                    break;
                case "*":
                    result = firstOperand * secondOperand;
                    break;
                case "/":
                    if (secondOperand == 0)
                    {
                        MessageBox.Show("Không thể chia cho 0.", "Lỗi",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                        btnClear_Click(this, EventArgs.Empty);
                        return;
                    }
                    result = firstOperand / secondOperand;
                    break;
                default:
                    return;
            }

            txtDisplay.Text = result.ToString();
            firstOperand = result;
        }
    }
}
